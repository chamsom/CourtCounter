# court_counter
Score keeping app for two teams in basketball using Google's Material Design spec.
